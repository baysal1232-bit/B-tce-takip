package com.example

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Borç ve Gider Kategorileri:
 * Kredi, Fatura, Kart, Ulaşım, Diğer
 */
enum class ExpenseCategory(
    val displayName: String,
    val color: Color
) {
    LOAN("Kredi", Color(0xFF1976D2)),
    BILL("Fatura", Color(0xFFE65100)),
    CARD("Kart", Color(0xFF7B1FA2)),
    TRANSPORT("Ulaşım", Color(0xFF00897B)),
    OTHER("Diğer", Color(0xFF546E7A));

    val icon: ImageVector
        get() = when (this) {
            LOAN -> Icons.Default.LocalAtm
            BILL -> Icons.Default.Receipt
            CARD -> Icons.Default.CreditCard
            TRANSPORT -> Icons.Default.DirectionsCar
            OTHER -> Icons.Default.MoreHoriz
        }

    companion object {
        fun fromString(name: String?): ExpenseCategory {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: OTHER
        }
    }
}
