package com.example

/**
 * Kullanıcının seçebileceği tema modu.
 */
enum class ThemeMode(val title: String) {
    SYSTEM("Sistem Teması"),
    LIGHT("Açık Tema"),
    DARK("Karanlık Tema")
}
