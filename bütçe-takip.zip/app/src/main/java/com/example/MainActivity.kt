package com.example

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import java.text.NumberFormat
import java.util.Locale

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.ui.draw.scale

class MainActivity : FragmentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(this, "Ödeme bildirimleri aktif edildi.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Android 13+ bildirim izni kontrolü
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = android.Manifest.permission.POST_NOTIFICATIONS
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(permission)
            }
        }

        setContent {
            val viewModel: BudgetViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            val isDarkTheme = when (uiState.themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                BudgetApp(activity = this, viewModel = viewModel)
            }
        }
    }
}

/**
 * Para birimini Türkçe Lira biçiminde formatlar (örn. "25.000,00 ₺").
 */
fun formatCurrency(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("tr", "TR")).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }
    return "${formatter.format(amount)} ₺"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetApp(
    activity: FragmentActivity,
    viewModel: BudgetViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showSalaryDialog by remember { mutableStateOf(false) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showSecuritySettingsDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<ExpenseEntity?>(null) }
    var expenseToDelete by remember { mutableStateOf<ExpenseEntity?>(null) }

    // Parmak izi kilit ekranı kontrolü
    if (uiState.isBiometricEnabled && !uiState.isAppUnlocked) {
        BiometricLockScreen(
            onAuthenticateClick = {
                BiometricHelper.showBiometricPrompt(
                    activity = activity,
                    onSuccess = { viewModel.unlockApp() },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "Cüzdan İkonu",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Bütçe Takip",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    // Tema Değiştirici Butonu (Karanlık / Açık / Sistem Modu)
                    IconButton(
                        onClick = { showThemeDialog = true },
                        modifier = Modifier.testTag("theme_mode_button")
                    ) {
                        Icon(
                            imageVector = when (uiState.themeMode) {
                                ThemeMode.DARK -> Icons.Default.DarkMode
                                ThemeMode.LIGHT -> Icons.Default.LightMode
                                ThemeMode.SYSTEM -> Icons.Default.BrightnessAuto
                            },
                            contentDescription = "Tema Modu",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // PDF Döküm Çıktısı Butonu
                    IconButton(
                        onClick = {
                            val success = ReportExporter.exportAndSharePdf(context, uiState)
                            if (success) {
                                Toast.makeText(context, "PDF Raporu oluşturuldu.", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "PDF oluşturulurken hata oluştu.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("export_pdf_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "PDF Raporu Al",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Güvenlik & Parmak İzi Ayarları
                    IconButton(
                        onClick = { showSecuritySettingsDialog = true },
                        modifier = Modifier.testTag("security_settings_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isBiometricEnabled) Icons.Default.Fingerprint else Icons.Default.Security,
                            contentDescription = "Güvenlik Ayarları",
                            tint = if (uiState.isBiometricEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Maaş Bilgisini Düzenleme Butonu
                    IconButton(
                        onClick = { showSalaryDialog = true },
                        modifier = Modifier.testTag("edit_salary_topbar_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Maaş Bilgisini Düzenle",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddExpenseDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Ekle İkonu") },
                text = { Text("Borç Ekle", fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("add_expense_fab"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Dashboard Kartı (Maaş, Cepte Kalan Bakiye, Toplam Borç, Otomatik Düşen)
            item {
                DashboardCard(
                    uiState = uiState,
                    onEditSalaryClick = { showSalaryDialog = true }
                )
            }

            // 2. Borç İlerleme Çubuğu (Ödenen / Toplam Borç Yüzdesi)
            item {
                DebtProgressCard(uiState = uiState)
            }

            // 3. Kategori Filtreleme Yatay Çipleri (Kredi, Fatura, Kart, Ulaşım, Diğer)
            item {
                CategoryFilterBar(
                    selectedCategory = uiState.selectedCategoryFilter,
                    onCategorySelected = { viewModel.selectCategoryFilter(it) }
                )
            }

            // 4. Durum Filtreleme Butonları (Tümü, Bekleyenler, Ödenenler)
            item {
                FilterRow(
                    currentFilter = uiState.filter,
                    onFilterSelected = { viewModel.setFilter(it) },
                    totalCount = uiState.expenses.size,
                    pendingCount = uiState.expenses.count { !it.isPaid },
                    paidCount = uiState.expenses.count { it.isPaid }
                )
            }

            // 5. Liste Başlığı ve PDF Rapor Hızlı Paylaşım Butonu
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Borç ve Gider Kalemleri",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${uiState.filteredExpenses.size} Kayıt",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 6. Boş Durum (Empty State)
            if (uiState.filteredExpenses.isEmpty()) {
                item {
                    EmptyExpensesCard(
                        filter = uiState.filter,
                        category = uiState.selectedCategoryFilter,
                        onAddClick = { showAddExpenseDialog = true }
                    )
                }
            } else {
                // 7. Borç Listesi Elemanları (Kategori İkonu, Taksit Takibi & Swipe-to-Dismiss / Swipe-to-Pay ile)
                items(
                    items = uiState.filteredExpenses,
                    key = { it.id }
                ) { expense ->
                    val dismissState = rememberSwipeToDismissBoxState(
                        confirmValueChange = { dismissValue ->
                            when (dismissValue) {
                                SwipeToDismissBoxValue.StartToEnd -> {
                                    // Sağa kaydırma: Ödendi durumunu değiştir (Swipe-to-Pay)
                                    viewModel.togglePaidStatus(expense)
                                    false // Kartı tamamen yok etme, resetle
                                }
                                SwipeToDismissBoxValue.EndToStart -> {
                                    // Sola kaydırma: Silme onayı diyaloğu aç (Swipe-to-Dismiss)
                                    expenseToDelete = expense
                                    false // Onay diyaloğuna bırak
                                }
                                SwipeToDismissBoxValue.Settled -> false
                            }
                        }
                    )

                    SwipeToDismissBox(
                        state = dismissState,
                        backgroundContent = {
                            val direction = dismissState.dismissDirection
                            val isStartToEnd = direction == SwipeToDismissBoxValue.StartToEnd
                            val bgColor by animateColorAsState(
                                targetValue = when (direction) {
                                    SwipeToDismissBoxValue.StartToEnd -> Color(0xFF2E7D32) // Yeşil: Öde / Ödendi yap
                                    SwipeToDismissBoxValue.EndToStart -> MaterialTheme.colorScheme.error // Kırmızı: Sil
                                    else -> Color.Transparent
                                },
                                label = "swipe_bg_color"
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(bgColor)
                                    .padding(horizontal = 20.dp),
                                contentAlignment = if (isStartToEnd) Alignment.CenterStart else Alignment.CenterEnd
                            ) {
                                if (isStartToEnd) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Ödendi Yap",
                                            tint = Color.White
                                        )
                                        Text(
                                            text = if (expense.isPaid) "Bekleyen Yap" else "Ödendi Yap",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                } else {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "Sil",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Sil",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    ) {
                        ExpenseItemCard(
                            expense = expense,
                            onTogglePaid = { viewModel.togglePaidStatus(expense) },
                            onEditClick = { expenseToEdit = expense },
                            onDeleteClick = { expenseToDelete = expense }
                        )
                    }
                }
            }

            // FAB için altta ekstra boşluk bırakma
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }

    // Diyaloglar
    if (showSalaryDialog) {
        SalaryEditDialog(
            currentSalary = uiState.salary,
            currentSalaryDay = uiState.salaryDay,
            onDismiss = { showSalaryDialog = false },
            onConfirm = { newSalary, newDay ->
                viewModel.updateSalary(newSalary, newDay)
                showSalaryDialog = false
            }
        )
    }

    if (showSecuritySettingsDialog) {
        SecuritySettingsDialog(
            isBiometricEnabled = uiState.isBiometricEnabled,
            isDeviceSupported = BiometricHelper.isBiometricAvailable(activity),
            onDismiss = { showSecuritySettingsDialog = false },
            onToggleBiometric = { enabled ->
                if (enabled) {
                    // Kullanıcı biyometriyi aktif ederken hemen test et
                    BiometricHelper.showBiometricPrompt(
                        activity = activity,
                        onSuccess = {
                            viewModel.setBiometricEnabled(true)
                            showSecuritySettingsDialog = false
                            Toast.makeText(context, "Parmak izi kilidi aktif edildi.", Toast.LENGTH_SHORT).show()
                        },
                        onError = { err ->
                            Toast.makeText(context, "Doğrulanamadı: $err", Toast.LENGTH_SHORT).show()
                        }
                    )
                } else {
                    viewModel.setBiometricEnabled(false)
                    showSecuritySettingsDialog = false
                    Toast.makeText(context, "Parmak izi kilidi kaldırıldı.", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    if (showAddExpenseDialog) {
        ExpenseAddEditDialog(
            expense = null,
            onDismiss = { showAddExpenseDialog = false },
            onConfirm = { title, amount, dueDateDay, isAutoDeduct, category, isInstallment, totalInstallments, remainingInstallments, _ ->
                viewModel.addExpense(
                    title = title,
                    amount = amount,
                    dueDateDay = dueDateDay,
                    isAutoDeduct = isAutoDeduct,
                    category = category,
                    isInstallment = isInstallment,
                    totalInstallments = totalInstallments,
                    remainingInstallments = remainingInstallments
                )
                showAddExpenseDialog = false
            }
        )
    }

    expenseToEdit?.let { expense ->
        ExpenseAddEditDialog(
            expense = expense,
            onDismiss = { expenseToEdit = null },
            onConfirm = { title, amount, dueDateDay, isAutoDeduct, category, isInstallment, totalInstallments, remainingInstallments, isPaid ->
                viewModel.updateExpense(
                    expense.copy(
                        title = title,
                        amount = amount,
                        dueDateDay = dueDateDay,
                        isAutoDeduct = isAutoDeduct,
                        category = category.name,
                        isInstallment = isInstallment,
                        totalInstallments = totalInstallments,
                        remainingInstallments = remainingInstallments,
                        isPaid = isPaid
                    )
                )
                expenseToEdit = null
            }
        )
    }

    if (showThemeDialog) {
        ThemeSelectionDialog(
            currentTheme = uiState.themeMode,
            onDismiss = { showThemeDialog = false },
            onSelectTheme = { selectedMode ->
                viewModel.setThemeMode(selectedMode)
                showThemeDialog = false
            }
        )
    }

    expenseToDelete?.let { expense ->
        DeleteConfirmationDialog(
            expenseTitle = expense.title,
            onDismiss = { expenseToDelete = null },
            onConfirm = {
                viewModel.deleteExpense(expense)
                expenseToDelete = null
            }
        )
    }
}

/**
 * Parmak İzi Kilit Ekranı.
 */
@Composable
fun BiometricLockScreen(onAuthenticateClick: () -> Unit) {
    LaunchedEffect(Unit) {
        onAuthenticateClick()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(100.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Kilitli",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            Text(
                text = "Uygulama Kilitli",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = "Bütçe ve borç bilgilerinize erişmek için parmak izinizi doğrulayın.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Button(
                onClick = onAuthenticateClick,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp)
                    .testTag("biometric_unlock_button")
            ) {
                Icon(Icons.Default.Fingerprint, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Parmak İzi ile Aç", fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Ana Bütçe Özeti Dashboard Kartı.
 */
@Composable
fun DashboardCard(
    uiState: BudgetUiState,
    onEditSalaryClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Üst Satır: Net Maaş Başlığı, Değeri ve Düzenle Butonu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Aylık Net Maaş",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Ayın ${uiState.salaryDay}. Günü",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = formatCurrency(uiState.salary),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                IconButton(
                    onClick = onEditSalaryClick,
                    modifier = Modifier.testTag("edit_salary_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Maaşı Güncelle",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.12f)
            )

            // Orta Vurgu: Cepte Kalan Net Bakiye
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                            )
                        )
                    )
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Cepte Kalan Net Bakiye",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "(Maaş - Toplam Borç)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val isPositive = uiState.remainingBalance >= 0
                        Text(
                            text = formatCurrency(uiState.remainingBalance),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isPositive) Color(0xFF1B873F) else MaterialTheme.colorScheme.error
                        )
                    }

                    Surface(
                        shape = CircleShape,
                        color = if (uiState.remainingBalance >= 0) {
                            Color(0xFFE8F5E9)
                        } else {
                            MaterialTheme.colorScheme.errorContainer
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (uiState.remainingBalance >= 0) {
                                    Icons.Default.Savings
                                } else {
                                    Icons.AutoMirrored.Filled.TrendingDown
                                },
                                contentDescription = "Bakiye Durumu",
                                tint = if (uiState.remainingBalance >= 0) {
                                    Color(0xFF2E7D32)
                                } else {
                                    MaterialTheme.colorScheme.error
                                }
                            )
                        }
                    }
                }
            }

            // Orta Bölüm 2: Günlük Harcama Limiti Hesaplayıcı Kartı
            // (Maaş - Toplam Borç) / (Maaş Gününe Kalan Gün)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("daily_budget_limit_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Today,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Günlük Harcama Limiti",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Maaş gününe ${uiState.daysUntilSalary} gün kaldı",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = formatCurrency(uiState.dailyBudgetLimit),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "/ gün",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Alt Satır: Toplam Borç ve Otomatik Düşen İstatistikleri
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricChip(
                    modifier = Modifier.weight(1f),
                    label = "Toplam Borç",
                    value = formatCurrency(uiState.totalDebt),
                    icon = Icons.Default.Payments,
                    iconColor = MaterialTheme.colorScheme.error
                )
                MetricChip(
                    modifier = Modifier.weight(1f),
                    label = "Otomatik Düşen",
                    value = formatCurrency(uiState.autoDeductTotal),
                    icon = Icons.Default.Autorenew,
                    iconColor = MaterialTheme.colorScheme.tertiary
                )
            }
        }
    }
}

/**
 * Küçük istatistik kartı bileşeni.
 */
@Composable
fun MetricChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/**
 * Borç İlerleme Çubuğu Kartı (Ödenen / Toplam Borç Oranı).
 */
@Composable
fun DebtProgressCard(uiState: BudgetUiState) {
    val animatedProgress by animateFloatAsState(
        targetValue = uiState.paidProgress,
        label = "progressAnimation"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("debt_progress_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HourglassEmpty,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Borç Ödeme Durumu",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                val percentText = (uiState.paidProgress * 100).toInt()
                Text(
                    text = "%$percentText Ödendi",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (percentText == 100) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                )
            }

            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = if (uiState.paidProgress >= 1f) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Ödenen: ${formatCurrency(uiState.totalPaid)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF2E7D32),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Kalan: ${formatCurrency(uiState.totalUnpaid)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * Kategori Filtreleme Çubuğu: Kredi, Fatura, Kart, Ulaşım, Diğer.
 */
@Composable
fun CategoryFilterBar(
    selectedCategory: ExpenseCategory?,
    onCategorySelected: (ExpenseCategory?) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = "Kategoriye Göre Filtrele",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Tümü Çipi
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onCategorySelected(null) },
                label = { Text("Tüm Kategoriler") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.ViewList,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                modifier = Modifier.testTag("category_filter_all")
            )

            ExpenseCategory.entries.forEach { category ->
                FilterChip(
                    selected = selectedCategory == category,
                    onClick = {
                        if (selectedCategory == category) onCategorySelected(null)
                        else onCategorySelected(category)
                    },
                    label = { Text(category.displayName) },
                    leadingIcon = {
                        Icon(
                            imageVector = category.icon,
                            contentDescription = category.displayName,
                            modifier = Modifier.size(16.dp),
                            tint = if (selectedCategory == category) MaterialTheme.colorScheme.onPrimary else category.color
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = category.color,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("category_filter_${category.name.lowercase()}")
                )
            }
        }
    }
}

/**
 * Filtreleme Satırı (Tümü, Bekleyenler, Ödenenler).
 */
@Composable
fun FilterRow(
    currentFilter: ExpenseFilter,
    onFilterSelected: (ExpenseFilter) -> Unit,
    totalCount: Int,
    pendingCount: Int,
    paidCount: Int
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = currentFilter == ExpenseFilter.ALL,
            onClick = { onFilterSelected(ExpenseFilter.ALL) },
            label = { Text("Tümü ($totalCount)") },
            modifier = Modifier.testTag("filter_all"),
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
            )
        )
        FilterChip(
            selected = currentFilter == ExpenseFilter.PENDING,
            onClick = { onFilterSelected(ExpenseFilter.PENDING) },
            label = { Text("Bekleyen ($pendingCount)") },
            modifier = Modifier.testTag("filter_pending"),
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.errorContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onErrorContainer
            )
        )
        FilterChip(
            selected = currentFilter == ExpenseFilter.PAID,
            onClick = { onFilterSelected(ExpenseFilter.PAID) },
            label = { Text("Ödenen ($paidCount)") },
            modifier = Modifier.testTag("filter_paid"),
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = Color(0xFFE8F5E9),
                selectedLabelColor = Color(0xFF1B5E20)
            )
        )
    }
}

/**
 * Tek bir Borç / Gider Kartı (Kategori İkonu ve Taksit Takibi ile).
 */
@Composable
fun ExpenseItemCard(
    expense: ExpenseEntity,
    onTogglePaid: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val category = ExpenseCategory.fromString(expense.category)

    val cardBgColor by animateColorAsState(
        targetValue = if (expense.isPaid) {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        label = "cardBgColor"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("expense_card_${expense.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (expense.isPaid) 0.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Sol Bölüm: Kategori İkonu ve Başlık
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (expense.isPaid) Color(0xFFE8F5E9) else category.color.copy(alpha = 0.15f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (expense.isPaid) Icons.Default.CheckCircle else category.icon,
                                contentDescription = category.displayName,
                                tint = if (expense.isPaid) Color(0xFF2E7D32) else category.color,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = expense.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textDecoration = if (expense.isPaid) TextDecoration.LineThrough else TextDecoration.None,
                                color = if (expense.isPaid) {
                                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                }
                            )

                            // Kategori Etiketi
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = category.color.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = category.displayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = category.color,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Son Gün: Ayın ${expense.dueDateDay}. günü",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Taksit Rozeti
                            if (expense.isInstallment) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = "${expense.remainingInstallments} / ${expense.totalInstallments} Taksit",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Sağ Bölüm: Tutar
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatCurrency(expense.amount),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (expense.isPaid) {
                            Color(0xFF2E7D32)
                        } else {
                            MaterialTheme.colorScheme.error
                        }
                    )
                }
            }

            // Rozetler ve Eylemler
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Otomatik Düşüş Rozeti
                    if (expense.isAutoDeduct) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Autorenew,
                                    contentDescription = "Otomatik Düşer",
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "Otomatik Düşer",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    }

                    // Ödendi / Bekliyor Rozeti
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (expense.isPaid) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                    ) {
                        Text(
                            text = if (expense.isPaid) "Ödendi" else "Bekliyor",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (expense.isPaid) Color(0xFF1B5E20) else Color(0xFFE65100),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Eylemler: Ödendi Switch, Düzenle, Sil Butonları
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Text(
                            text = "Ödendi",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (expense.isPaid) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Switch(
                            checked = expense.isPaid,
                            onCheckedChange = { onTogglePaid() },
                            modifier = Modifier.testTag("toggle_paid_${expense.id}"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF2E7D32)
                            ),
                            thumbContent = if (expense.isPaid) {
                                {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                        tint = Color(0xFF2E7D32)
                                    )
                                }
                            } else null
                        )
                    }

                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("edit_expense_${expense.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Düzenle",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_expense_${expense.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Sil",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Boş Liste Kartı.
 */
@Composable
fun EmptyExpensesCard(
    filter: ExpenseFilter,
    category: ExpenseCategory?,
    onAddClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_expenses_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = category?.icon ?: Icons.Default.Savings,
                        contentDescription = null,
                        tint = category?.color ?: MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            val title = if (category != null) {
                "${category.displayName} Kategorisinde Kayıt Yok"
            } else when (filter) {
                ExpenseFilter.ALL -> "Henüz Borç veya Gider Yok"
                ExpenseFilter.PENDING -> "Bekleyen Borcunuz Yok!"
                ExpenseFilter.PAID -> "Henüz Ödenen Borç Bulunmuyor"
            }

            val description = when {
                category != null -> "${category.displayName} kategorisine ait yeni bir borç veya fatura ekleyin."
                filter == ExpenseFilter.ALL -> "Kredi, fatura, kredi kartı gibi borçlarınızı ekleyerek bütçenizi kontrol altına alın."
                filter == ExpenseFilter.PENDING -> "Harika! Şu anda ödenmeyi bekleyen aktif bir borcunuz bulunmuyor."
                else -> "Borçlarınızı ödedikçe 'Ödendi' olarak işaretleyin."
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (filter == ExpenseFilter.ALL) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAddClick,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Borç Ekle")
                }
            }
        }
    }
}

/**
 * Net Maaş ve Maaş Günü Düzenleme Diyaloğu.
 */
@Composable
fun SalaryEditDialog(
    currentSalary: Double,
    currentSalaryDay: Int,
    onDismiss: () -> Unit,
    onConfirm: (Double, Int) -> Unit
) {
    var salaryText by remember { mutableStateOf(if (currentSalary > 0) currentSalary.toInt().toString() else "") }
    var dayText by remember { mutableStateOf(currentSalaryDay.toString()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text("Maaş Bilgilerini Güncelle", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Aylık net maaşınızı ve her ay maaşın yattığı günü belirleyin:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = salaryText,
                    onValueChange = {
                        salaryText = it
                        errorMessage = null
                    },
                    label = { Text("Aylık Net Maaş (₺)") },
                    placeholder = { Text("Örn: 45000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("salary_input")
                )

                OutlinedTextField(
                    value = dayText,
                    onValueChange = {
                        dayText = it
                        errorMessage = null
                    },
                    label = { Text("Maaş Günü (1 - 31)") },
                    placeholder = { Text("Örn: 1 veya 15") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("salary_day_input")
                )

                errorMessage?.let { msg ->
                    Text(
                        text = msg,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedSalary = salaryText.toDoubleOrNull()
                    val parsedDay = dayText.toIntOrNull()

                    if (parsedSalary == null || parsedSalary < 0) {
                        errorMessage = "Lütfen geçerli bir maaş tutarı giriniz."
                        return@Button
                    }
                    if (parsedDay == null || parsedDay !in 1..31) {
                        errorMessage = "Maaş günü 1 ile 31 arasında olmalıdır."
                        return@Button
                    }

                    onConfirm(parsedSalary, parsedDay)
                },
                modifier = Modifier.testTag("save_salary_button")
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}

/**
 * Güvenlik ve Parmak İzi Ayarları Diyaloğu.
 */
@Composable
fun SecuritySettingsDialog(
    isBiometricEnabled: Boolean,
    isDeviceSupported: Boolean,
    onDismiss: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Fingerprint,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text("Güvenlik Ayarları", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Uygulama her açıldığında biyometrik kimlik doğrulaması (Parmak İzi / Yüz Tanıma) isteyerek finansal verilerinizi koruyun.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Biyometrik Kilit",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (isDeviceSupported) {
                                    if (isBiometricEnabled) "Aktif (Parmak İzi devrede)" else "Devre dışı"
                                } else {
                                    "Cihazınızda biyometrik donanım bulunamadı"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (!isDeviceSupported) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Switch(
                            checked = isBiometricEnabled,
                            onCheckedChange = { onToggleBiometric(it) },
                            enabled = isDeviceSupported,
                            modifier = Modifier.testTag("biometric_toggle_switch")
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Tamam")
            }
        }
    )
}

/**
 * Borç Ekleme ve Düzenleme Diyaloğu (Kategori ve Taksit Takibi ile).
 */
@Composable
fun ExpenseAddEditDialog(
    expense: ExpenseEntity?,
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        amount: Double,
        dueDateDay: Int,
        isAutoDeduct: Boolean,
        category: ExpenseCategory,
        isInstallment: Boolean,
        totalInstallments: Int,
        remainingInstallments: Int,
        isPaid: Boolean
    ) -> Unit
) {
    val isEditing = expense != null

    var title by remember { mutableStateOf(expense?.title ?: "") }
    var amountText by remember { mutableStateOf(expense?.amount?.let { if (it % 1 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var dueDateDayText by remember { mutableStateOf(expense?.dueDateDay?.toString() ?: "15") }
    var isAutoDeduct by remember { mutableStateOf(expense?.isAutoDeduct ?: false) }
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.fromString(expense?.category)) }

    // Taksit State'leri
    var isInstallment by remember { mutableStateOf(expense?.isInstallment ?: false) }
    var totalInstallmentsText by remember { mutableStateOf(expense?.totalInstallments?.toString() ?: "12") }
    var remainingInstallmentsText by remember { mutableStateOf(expense?.remainingInstallments?.toString() ?: "12") }

    var isPaid by remember { mutableStateOf(expense?.isPaid ?: false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Borcu Düzenle" else "Yeni Borç / Gider Ekle",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Borç Adı
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = {
                            title = it
                            errorMessage = null
                        },
                        label = { Text("Borç / Gider Adı") },
                        placeholder = { Text("Örn: Kira, Kredi Kartı, İnternet") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("expense_title_input")
                    )
                }

                // Kategori Seçimi (Kredi, Fatura, Kart, Ulaşım, Diğer)
                item {
                    Text(
                        text = "Kategori Seçimi",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ExpenseCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat.displayName) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = cat.icon,
                                        contentDescription = cat.displayName,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedCategory == cat) MaterialTheme.colorScheme.onPrimary else cat.color
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = cat.color,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                // Tutar
                item {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = {
                            amountText = it.replace(',', '.')
                            errorMessage = null
                        },
                        label = { Text("Aylık Tutar (₺)") },
                        placeholder = { Text("Örn: 7500") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("expense_amount_input")
                    )
                }

                // Son Ödeme Günü
                item {
                    OutlinedTextField(
                        value = dueDateDayText,
                        onValueChange = {
                            dueDateDayText = it
                            errorMessage = null
                        },
                        label = { Text("Son Ödeme Günü (Ayın 1 - 31'i)") },
                        placeholder = { Text("Örn: 15") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("expense_due_day_input")
                    )
                }

                // Taksitli Borç Switch ve Alanları
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Taksitli Borç",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Kredi veya taksitli alışveriş takibi",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = isInstallment,
                                    onCheckedChange = { isInstallment = it },
                                    modifier = Modifier.testTag("expense_installment_switch")
                                )
                            }

                            AnimatedVisibility(visible = isInstallment) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = remainingInstallmentsText,
                                        onValueChange = { remainingInstallmentsText = it },
                                        label = { Text("Kalan Taksit") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = totalInstallmentsText,
                                        onValueChange = { totalInstallmentsText = it },
                                        label = { Text("Toplam Taksit") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Otomatik Maaştan Düşme Switch'i
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Maaştan otomatik düşsün mü?",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Otomatik ödeme talimatı varsa işaretleyin",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = isAutoDeduct,
                                onCheckedChange = { isAutoDeduct = it },
                                modifier = Modifier.testTag("expense_auto_deduct_switch")
                            )
                        }
                    }
                }

                // Düzenleme modunda ödendi durumu
                if (isEditing) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Ödendi Olarak İşaretle",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Switch(
                                    checked = isPaid,
                                    onCheckedChange = { isPaid = it },
                                    modifier = Modifier.testTag("expense_dialog_is_paid_switch")
                                )
                            }
                        }
                    }
                }

                errorMessage?.let { msg ->
                    item {
                        Text(
                            text = msg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        errorMessage = "Lütfen borç adı giriniz."
                        return@Button
                    }
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0) {
                        errorMessage = "Lütfen 0'dan büyük geçerli bir tutar giriniz."
                        return@Button
                    }
                    val day = dueDateDayText.toIntOrNull()
                    if (day == null || day !in 1..31) {
                        errorMessage = "Son ödeme günü 1 ile 31 arasında olmalıdır."
                        return@Button
                    }

                    var totalInst = 1
                    var remInst = 1
                    if (isInstallment) {
                        val parsedTotal = totalInstallmentsText.toIntOrNull()
                        val parsedRem = remainingInstallmentsText.toIntOrNull()
                        if (parsedTotal == null || parsedTotal < 1) {
                            errorMessage = "Toplam taksit en az 1 olmalıdır."
                            return@Button
                        }
                        if (parsedRem == null || parsedRem < 1 || parsedRem > parsedTotal) {
                            errorMessage = "Kalan taksit 1 ile toplam taksit arasında olmalıdır."
                            return@Button
                        }
                        totalInst = parsedTotal
                        remInst = parsedRem
                    }

                    onConfirm(
                        title.trim(),
                        amount,
                        day,
                        isAutoDeduct,
                        selectedCategory,
                        isInstallment,
                        totalInst,
                        remInst,
                        isPaid
                    )
                },
                modifier = Modifier.testTag("save_expense_button")
            ) {
                Text(if (isEditing) "Güncelle" else "Ekle")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}

/**
 * Borç Silme Onaylama Diyaloğu.
 */
@Composable
fun DeleteConfirmationDialog(
    expenseTitle: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Borcu Sil", fontWeight = FontWeight.Bold)
        },
        text = {
            Text(
                text = "\"$expenseTitle\" başlıklı borcu silmek istediğinize emin misiniz? Bu işlem geri alınamaz."
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                modifier = Modifier.testTag("confirm_delete_button")
            ) {
                Text("Sil")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Vazgeç")
            }
        }
    )
}

/**
 * Açık / Karanlık / Sistem Teması Seçim Diyaloğu.
 */
@Composable
fun ThemeSelectionDialog(
    currentTheme: ThemeMode,
    onDismiss: () -> Unit,
    onSelectTheme: (ThemeMode) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BrightnessAuto,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text("Tema Görünümü", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Uygulamanın açık, karanlık veya sistem temasına uyum sağlamasını seçebilirsiniz.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))

                ThemeMode.entries.forEach { mode ->
                    val isSelected = currentTheme == mode
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectTheme(mode) }
                            .testTag("theme_option_${mode.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = when (mode) {
                                    ThemeMode.SYSTEM -> Icons.Default.BrightnessAuto
                                    ThemeMode.LIGHT -> Icons.Default.LightMode
                                    ThemeMode.DARK -> Icons.Default.DarkMode
                                },
                                contentDescription = mode.title,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = mode.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat")
            }
        }
    )
}
