package com.example

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Bütçe özetini ve borç listesini PDF raporu olarak dışa aktaran ve paylaşan yardımcı sınıf.
 */
object ReportExporter {

    /**
     * Bütçe raporunu PDF dosyası olarak oluşturur ve Android Share Intent başlatır.
     */
    fun exportAndSharePdf(
        context: Context,
        uiState: BudgetUiState
    ): Boolean {
        return try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.rgb(20, 40, 80)
                textSize = 22f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val subtitlePaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 12f
                typeface = Typeface.DEFAULT
                isAntiAlias = true
            }

            val headerPaint = Paint().apply {
                color = Color.rgb(30, 70, 120)
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val textPaint = Paint().apply {
                color = Color.BLACK
                textSize = 11f
                typeface = Typeface.DEFAULT
                isAntiAlias = true
            }

            val tableHeaderBg = Paint().apply {
                color = Color.rgb(235, 240, 248)
                style = Paint.Style.FILL
            }

            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1f
            }

            var currentY = 50f

            // Başlık
            canvas.drawText("BÜTÇE VE BORÇ TAKİP RAPORU", 40f, currentY, titlePaint)
            currentY += 20f

            val dateFormat = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("tr", "TR"))
            canvas.drawText("Rapor Tarihi: ${dateFormat.format(Date())}", 40f, currentY, subtitlePaint)
            currentY += 30f

            // Dashboard Özeti
            canvas.drawRect(40f, currentY, (pageWidth - 40).toFloat(), currentY + 105f, tableHeaderBg)

            val summaryTitlePaint = Paint().apply {
                color = Color.rgb(20, 60, 110)
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            canvas.drawText("Aylık Finansal Özet", 55f, currentY + 24f, summaryTitlePaint)
            canvas.drawText("Net Maaş: ${formatCurrency(uiState.salary)} (Ayın ${uiState.salaryDay}. günü)", 55f, currentY + 45f, textPaint)
            canvas.drawText("Toplam Borç: ${formatCurrency(uiState.totalDebt)}", 55f, currentY + 65f, textPaint)
            canvas.drawText("Ödenen Borç: ${formatCurrency(uiState.totalPaid)} | Kalan Borç: ${formatCurrency(uiState.totalUnpaid)}", 55f, currentY + 85f, textPaint)

            canvas.drawText("Otomatik Düşen: ${formatCurrency(uiState.autoDeductTotal)}", 330f, currentY + 45f, textPaint)
            val balanceColor = if (uiState.remainingBalance >= 0) Color.rgb(20, 130, 40) else Color.RED
            val balancePaint = Paint().apply {
                color = balanceColor
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("Cepte Kalan Net: ${formatCurrency(uiState.remainingBalance)}", 330f, currentY + 65f, balancePaint)
            val percent = (uiState.paidProgress * 100).toInt()
            canvas.drawText("Ödeme Tamamlanma: %$percent", 330f, currentY + 85f, textPaint)

            currentY += 130f

            // Borç Listesi Başlığı
            canvas.drawText("Borç ve Gider Kalemleri (${uiState.expenses.size} Adet)", 40f, currentY, headerPaint)
            currentY += 16f

            // Tablo Başlıkları
            canvas.drawRect(40f, currentY, (pageWidth - 40).toFloat(), currentY + 25f, tableHeaderBg)
            val colHeaderPaint = Paint().apply {
                color = Color.rgb(40, 40, 40)
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("Borç Adı", 50f, currentY + 17f, colHeaderPaint)
            canvas.drawText("Kategori", 200f, currentY + 17f, colHeaderPaint)
            canvas.drawText("Taksit", 270f, currentY + 17f, colHeaderPaint)
            canvas.drawText("Son Gün", 335f, currentY + 17f, colHeaderPaint)
            canvas.drawText("Tutar", 405f, currentY + 17f, colHeaderPaint)
            canvas.drawText("Durum", 480f, currentY + 17f, colHeaderPaint)
            currentY += 25f

            // Tablo Satırları
            for (expense in uiState.expenses) {
                if (currentY > pageHeight - 60f) break // Sayfa sonu

                val categoryName = ExpenseCategory.fromString(expense.category).displayName
                val installmentInfo = if (expense.isInstallment) "${expense.remainingInstallments}/${expense.totalInstallments}" else "-"
                val statusText = if (expense.isPaid) "Ödendi" else "Bekliyor"
                val autoText = if (expense.isAutoDeduct) " (Oto)" else ""

                canvas.drawText(expense.title.take(20), 50f, currentY + 18f, textPaint)
                canvas.drawText(categoryName, 200f, currentY + 18f, textPaint)
                canvas.drawText(installmentInfo, 270f, currentY + 18f, textPaint)
                canvas.drawText("Ayın ${expense.dueDateDay}'i", 335f, currentY + 18f, textPaint)
                canvas.drawText(formatCurrency(expense.amount) + autoText, 405f, currentY + 18f, textPaint)

                val statusPaint = Paint().apply {
                    color = if (expense.isPaid) Color.rgb(25, 125, 35) else Color.rgb(200, 70, 0)
                    textSize = 10f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }
                canvas.drawText(statusText, 480f, currentY + 18f, statusPaint)

                currentY += 26f
                canvas.drawLine(40f, currentY, (pageWidth - 40).toFloat(), currentY, linePaint)
            }

            pdfDocument.finishPage(page)

            // PDF Dosyasını Kaydetme
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val pdfFile = File(reportsDir, "Butce_Raporu_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()

            // Paylaşım Intent'i Başlatma
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Bütçe ve Borç Takip Raporu")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Bütçe Raporunu Paylaş / Aç")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
