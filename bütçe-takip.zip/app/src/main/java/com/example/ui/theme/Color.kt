package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Emerald / Forest Theme)
val PrimaryLight = Color(0xFF006C4C)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFF8CF8C7)
val OnPrimaryContainerLight = Color(0xFF002114)

val SecondaryLight = Color(0xFF4C6356)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCEE9D7)
val OnSecondaryContainerLight = Color(0xFF092015)

val TertiaryLight = Color(0xFF3D6373)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFC1E8FB)
val OnTertiaryContainerLight = Color(0xFF001F29)

val BackgroundLight = Color(0xFFFBFDF9)
val OnBackgroundLight = Color(0xFF191C1A)
val SurfaceLight = Color(0xFFFBFDF9)
val OnSurfaceLight = Color(0xFF191C1A)
val SurfaceVariantLight = Color(0xFFDBE5DE)
val OnSurfaceVariantLight = Color(0xFF404944)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

// Dark Theme Colors
val PrimaryDark = Color(0xFF70DBAC)
val OnPrimaryDark = Color(0xFF003825)
val PrimaryContainerDark = Color(0xFF005238)
val OnPrimaryContainerDark = Color(0xFF8CF8C7)

val SecondaryDark = Color(0xFFB3CCBC)
val OnSecondaryDark = Color(0xFF1F3529)
val SecondaryContainerDark = Color(0xFF354C3F)
val OnSecondaryContainerDark = Color(0xFFCEE9D7)

val TertiaryDark = Color(0xFFA5CCDF)
val OnTertiaryDark = Color(0xFF073544)
val TertiaryContainerDark = Color(0xFF244C5B)
val OnTertiaryContainerDark = Color(0xFFC1E8FB)

val BackgroundDark = Color(0xFF191C1A)
val OnBackgroundDark = Color(0xFFE1E3DF)
val SurfaceDark = Color(0xFF191C1A)
val OnSurfaceDark = Color(0xFFE1E3DF)
val SurfaceVariantDark = Color(0xFF404944)
val OnSurfaceVariantDark = Color(0xFFBFC9C2)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

