package com.example

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.widget.BudgetAppWidgetProvider
import java.util.Calendar

/**
 * Borç filtreleme seçenekleri.
 */
enum class ExpenseFilter {
    ALL,
    PENDING,
    PAID
}

/**
 * Kullanıcı arayüzünün (UI) ihtiyaç duyduğu tüm bütçe verilerini içeren durum sınıfı.
 */
data class BudgetUiState(
    val salary: Double = 35000.0,
    val salaryDay: Int = 1,
    val expenses: List<ExpenseEntity> = emptyList(),
    val filteredExpenses: List<ExpenseEntity> = emptyList(),
    val totalDebt: Double = 0.0,
    val totalPaid: Double = 0.0,
    val totalUnpaid: Double = 0.0,
    val autoDeductTotal: Double = 0.0,
    val remainingBalance: Double = 35000.0,
    val dailyBudgetLimit: Double = 0.0,
    val daysUntilSalary: Int = 1,
    val paidProgress: Float = 0f,
    val filter: ExpenseFilter = ExpenseFilter.ALL,
    val selectedCategoryFilter: ExpenseCategory? = null,
    val isBiometricEnabled: Boolean = false,
    val isAppUnlocked: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM
)

/**
 * Bütçe ve borç durumunu yöneten, hesaplamaları yapan ViewModel.
 */
class BudgetViewModel(application: Application) : AndroidViewModel(application) {

    private val expenseDao: ExpenseDao = AppDatabase.getDatabase(application).expenseDao()
    private val sharedPreferences: SharedPreferences =
        application.getSharedPreferences("budget_preferences", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SALARY = "key_salary"
        private const val KEY_SALARY_DAY = "key_salary_day"
        private const val KEY_BIOMETRIC_ENABLED = "key_biometric_enabled"
        private const val KEY_THEME_MODE = "key_theme_mode"
        private const val DEFAULT_SALARY = 35000.0
        private const val DEFAULT_SALARY_DAY = 1
    }

    private val _salary = MutableStateFlow(
        sharedPreferences.getFloat(KEY_SALARY, DEFAULT_SALARY.toFloat()).toDouble()
    )
    val salary: StateFlow<Double> = _salary

    private val _salaryDay = MutableStateFlow(
        sharedPreferences.getInt(KEY_SALARY_DAY, DEFAULT_SALARY_DAY)
    )
    val salaryDay: StateFlow<Int> = _salaryDay

    private val _filter = MutableStateFlow(ExpenseFilter.ALL)
    val filter: StateFlow<ExpenseFilter> = _filter

    private val _selectedCategoryFilter = MutableStateFlow<ExpenseCategory?>(null)
    val selectedCategoryFilter: StateFlow<ExpenseCategory?> = _selectedCategoryFilter

    private val _themeMode = MutableStateFlow(
        try {
            ThemeMode.valueOf(
                sharedPreferences.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
            )
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        }
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode

    private val _isBiometricEnabled = MutableStateFlow(
        sharedPreferences.getBoolean(KEY_BIOMETRIC_ENABLED, false)
    )
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled

    // Eğer biyometrik kilit kapalıysa uygulama baştan açık başlar; açıksa kilitli başlar.
    private val _isAppUnlocked = MutableStateFlow(!_isBiometricEnabled.value)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked

    init {
        // WorkManager günlük bildirimini başlat
        DueDateReminderWorker.scheduleDailyReminder(application)
    }

    val uiState: StateFlow<BudgetUiState> = combine(
        expenseDao.getAllExpenses(),
        _salary,
        _salaryDay,
        _filter,
        _selectedCategoryFilter,
        _isBiometricEnabled,
        _isAppUnlocked,
        _themeMode
    ) { args: Array<Any?> ->
        @Suppress("UNCHECKED_CAST")
        val expensesList = args[0] as List<ExpenseEntity>
        val currentSalary = args[1] as Double
        val currentSalaryDay = args[2] as Int
        val currentFilter = args[3] as ExpenseFilter
        val currentCatFilter = args[4] as? ExpenseCategory
        val bioEnabled = args[5] as Boolean
        val unlocked = args[6] as Boolean
        val curThemeMode = args[7] as ThemeMode

        val totalDebt = expensesList.sumOf { it.amount }
        val totalPaid = expensesList.filter { it.isPaid }.sumOf { it.amount }
        val totalUnpaid = expensesList.filter { !it.isPaid }.sumOf { it.amount }
        val autoDeductTotal = expensesList.filter { it.isAutoDeduct }.sumOf { it.amount }
        val remainingBalance = currentSalary - totalDebt
        val progress = if (totalDebt > 0) (totalPaid / totalDebt).toFloat().coerceIn(0f, 1f) else 0f

        // 1. Günlük Harcama Limiti Hesaplayıcı Mantığı:
        // (Maaş - Toplam Borç) / (Maaş Gününe Kalan Gün)
        val now = Calendar.getInstance()
        val currentDay = now.get(Calendar.DAY_OF_MONTH)
        val maxDayThisMonth = now.getActualMaximum(Calendar.DAY_OF_MONTH)
        val daysUntil = if (currentSalaryDay > currentDay) {
            currentSalaryDay - currentDay
        } else if (currentSalaryDay == currentDay) {
            1
        } else {
            (maxDayThisMonth - currentDay) + currentSalaryDay
        }.coerceAtLeast(1)

        val dailyLimit = if (remainingBalance > 0) {
            remainingBalance / daysUntil
        } else {
            0.0
        }

        val filtered = expensesList.filter { expense ->
            val statusMatch = when (currentFilter) {
                ExpenseFilter.ALL -> true
                ExpenseFilter.PENDING -> !expense.isPaid
                ExpenseFilter.PAID -> expense.isPaid
            }
            val categoryMatch = currentCatFilter == null || expense.category == currentCatFilter.name
            statusMatch && categoryMatch
        }

        BudgetUiState(
            salary = currentSalary,
            salaryDay = currentSalaryDay,
            expenses = expensesList,
            filteredExpenses = filtered,
            totalDebt = totalDebt,
            totalPaid = totalPaid,
            totalUnpaid = totalUnpaid,
            autoDeductTotal = autoDeductTotal,
            remainingBalance = remainingBalance,
            dailyBudgetLimit = dailyLimit,
            daysUntilSalary = daysUntil,
            paidProgress = progress,
            filter = currentFilter,
            selectedCategoryFilter = currentCatFilter,
            isBiometricEnabled = bioEnabled,
            isAppUnlocked = unlocked,
            themeMode = curThemeMode
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BudgetUiState()
    )

    /**
     * Tema modunu (Sistem, Açık, Karanlık) günceller ve saklar.
     */
    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        sharedPreferences.edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    /**
     * Kullanıcının net maaşını ve maaş gününü günceller ve saklar.
     */
    fun updateSalary(newSalary: Double, newSalaryDay: Int) {
        val validDay = newSalaryDay.coerceIn(1, 31)
        val validSalary = if (newSalary < 0) 0.0 else newSalary

        _salary.value = validSalary
        _salaryDay.value = validDay

        sharedPreferences.edit()
            .putFloat(KEY_SALARY, validSalary.toFloat())
            .putInt(KEY_SALARY_DAY, validDay)
            .apply()

        BudgetAppWidgetProvider.notifyDataChanged(getApplication())
    }

    /**
     * Filtreleme türünü günceller (Tümü, Bekleyenler, Ödenenler).
     */
    fun setFilter(filter: ExpenseFilter) {
        _filter.value = filter
    }

    /**
     * Kategori filtresini günceller veya sıfırlar.
     */
    fun selectCategoryFilter(category: ExpenseCategory?) {
        _selectedCategoryFilter.value = category
    }

    /**
     * Biyometrik kilit tercihini günceller.
     */
    fun setBiometricEnabled(enabled: Boolean) {
        _isBiometricEnabled.value = enabled
        sharedPreferences.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
        if (!enabled) {
            _isAppUnlocked.value = true
        }
    }

    /**
     * Uygulama kilidini başarılı doğrulama sonrası açar.
     */
    fun unlockApp() {
        _isAppUnlocked.value = true
    }

    /**
     * Yeni bir borç / gider ekler (Kategori ve Taksit desteği dahil).
     */
    fun addExpense(
        title: String,
        amount: Double,
        dueDateDay: Int,
        isAutoDeduct: Boolean,
        category: ExpenseCategory = ExpenseCategory.OTHER,
        isInstallment: Boolean = false,
        totalInstallments: Int = 1,
        remainingInstallments: Int = 1
    ) {
        viewModelScope.launch {
            val expense = ExpenseEntity(
                title = title.trim(),
                amount = amount,
                dueDateDay = dueDateDay.coerceIn(1, 31),
                isAutoDeduct = isAutoDeduct,
                isPaid = false,
                category = category.name,
                isInstallment = isInstallment,
                totalInstallments = if (isInstallment) totalInstallments.coerceAtLeast(1) else 1,
                remainingInstallments = if (isInstallment) remainingInstallments.coerceIn(1, totalInstallments) else 1
            )
            expenseDao.insertExpense(expense)
            BudgetAppWidgetProvider.notifyDataChanged(getApplication())
        }
    }

    /**
     * Mevcut bir borcu günceller.
     */
    fun updateExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            expenseDao.updateExpense(expense)
            BudgetAppWidgetProvider.notifyDataChanged(getApplication())
        }
    }

    /**
     * Bir borcu veritabanından siler.
     */
    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            expenseDao.deleteExpense(expense)
            BudgetAppWidgetProvider.notifyDataChanged(getApplication())
        }
    }

    /**
     * Bir borcun ödendi durumunu tersine çevirir (toggle).
     * Eğer taksitli bir borç ödendiyse ve kalan taksit sayısı > 1 ise taksit sayısını azaltma desteği de sağlanabilir.
     */
    fun togglePaidStatus(expense: ExpenseEntity) {
        viewModelScope.launch {
            val nextPaidState = !expense.isPaid
            if (nextPaidState && expense.isInstallment && expense.remainingInstallments > 1) {
                // Taksit ödendiğinde kalan taksiti 1 azalt
                expenseDao.updateExpense(
                    expense.copy(
                        isPaid = true,
                        remainingInstallments = expense.remainingInstallments - 1
                    )
                )
            } else {
                expenseDao.updatePaidStatus(expense.id, nextPaidState)
            }
            BudgetAppWidgetProvider.notifyDataChanged(getApplication())
        }
    }
}
