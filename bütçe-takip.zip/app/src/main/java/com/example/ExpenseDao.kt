package com.example

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Borç ve gider veritabanı işlemlerini yöneten DAO (Data Access Object) arayüzü.
 */
@Dao
interface ExpenseDao {

    /**
     * Tüm borçları listeler. Ödenmemişler önce, son ödeme gününe göre sıralanır.
     */
    @Query("SELECT * FROM expenses ORDER BY isPaid ASC, dueDateDay ASC, id DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    /**
     * Worker ve raporlama için anlık tek seferlik liste alır.
     */
    @Query("SELECT * FROM expenses ORDER BY isPaid ASC, dueDateDay ASC, id DESC")
    suspend fun getAllExpensesList(): List<ExpenseEntity>

    /**
     * Yeni bir borç veya gider ekler.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    /**
     * Mevcut bir borcu günceller.
     */
    @Update
    suspend fun updateExpense(expense: ExpenseEntity)

    /**
     * Belirtilen borcu veritabanından siler.
     */
    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    /**
     * ID'ye göre borcu siler.
     */
    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpenseById(id: Int)

    /**
     * Bir borcun ödendi durumunu hızlıca günceller.
     */
    @Query("UPDATE expenses SET isPaid = :isPaid WHERE id = :id")
    suspend fun updatePaidStatus(id: Int, isPaid: Boolean)
}
