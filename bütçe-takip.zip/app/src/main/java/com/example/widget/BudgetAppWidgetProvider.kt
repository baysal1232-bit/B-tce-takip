package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.AppDatabase
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

/**
 * Android AppWidget: Ana ekranda Bütçe ve Kalan Net Bakiye ile Günlük Harcama Limitini gösterir.
 */
class BudgetAppWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE_BUDGET_WIDGET) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, BudgetAppWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            onUpdate(context, appWidgetManager, appWidgetIds)
        }
    }

    companion object {
        const val ACTION_UPDATE_BUDGET_WIDGET = "com.example.widget.ACTION_UPDATE_BUDGET_WIDGET"

        fun notifyDataChanged(context: Context) {
            val intent = Intent(context, BudgetAppWidgetProvider::class.java).apply {
                action = ACTION_UPDATE_BUDGET_WIDGET
            }
            context.sendBroadcast(intent)
        }

        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            // Arka planda verileri oku ve RemoteViews'i güncelle
            CoroutineScope(Dispatchers.IO).launch {
                val prefs = context.getSharedPreferences("budget_preferences", Context.MODE_PRIVATE)
                val salary = prefs.getFloat("key_salary", 35000f).toDouble()
                val salaryDay = prefs.getInt("key_salary_day", 1)

                val dao = AppDatabase.getDatabase(context).expenseDao()
                val expenses = dao.getAllExpensesList()

                val totalDebt = expenses.sumOf { it.amount }
                val remainingBalance = salary - totalDebt

                // Kalan Gün & Günlük Limit
                val now = Calendar.getInstance()
                val currentDay = now.get(Calendar.DAY_OF_MONTH)
                val maxDayThisMonth = now.getActualMaximum(Calendar.DAY_OF_MONTH)
                val daysUntilSalary = if (salaryDay > currentDay) {
                    salaryDay - currentDay
                } else if (salaryDay == currentDay) {
                    1
                } else {
                    (maxDayThisMonth - currentDay) + salaryDay
                }.coerceAtLeast(1)

                val dailyLimit = if (remainingBalance > 0) remainingBalance / daysUntilSalary else 0.0

                val currencyFormat = NumberFormat.getNumberInstance(Locale("tr", "TR")).apply {
                    minimumFractionDigits = 0
                    maximumFractionDigits = 0
                }

                val formattedBalance = "${currencyFormat.format(remainingBalance)} ₺"
                val formattedDaily = "${currencyFormat.format(dailyLimit)} ₺/gün"

                val views = RemoteViews(context.packageName, R.layout.widget_budget_layout).apply {
                    setTextViewText(R.id.widget_balance_text, formattedBalance)
                    setTextViewText(R.id.widget_daily_limit_text, "Günlük Limit: $formattedDaily")
                    setTextViewText(R.id.widget_days_left_text, "Maaşa $daysUntilSalary Gün")

                    // Tıklanınca uygulamayı aç
                    val clickIntent = Intent(context, MainActivity::class.java)
                    val pendingIntent = PendingIntent.getActivity(
                        context,
                        0,
                        clickIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                }

                appWidgetManager.updateAppWidget(appWidgetId, views)
            }
        }
    }
}
