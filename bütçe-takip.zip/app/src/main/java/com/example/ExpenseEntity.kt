package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Borç / Gider tablosu için Room Database Entity modeli.
 *
 * @property id Benzersiz otomatik artan birincil anahtar
 * @property title Borç veya gider adı (örn. "Ev Kirası", "Kredi Kartı", "İnternet")
 * @property amount Gider tutarı (TL)
 * @property dueDateDay Ayın kaçıncı günü ödeneceği (1 - 31)
 * @property isAutoDeduct Maaştan otomatik düşülsün mü? (Otomatik ödeme talimatı)
 * @property isPaid Bu borç ödendi mi?
 * @property category Kategori (LOAN, BILL, CARD, TRANSPORT, OTHER)
 * @property isInstallment Taksitli bir borç mu?
 * @property totalInstallments Toplam taksit sayısı (örn. 12)
 * @property remainingInstallments Kalan taksit sayısı (örn. 5)
 */
@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val amount: Double,
    val dueDateDay: Int,
    val isAutoDeduct: Boolean = false,
    val isPaid: Boolean = false,
    val category: String = ExpenseCategory.OTHER.name,
    val isInstallment: Boolean = false,
    val totalInstallments: Int = 1,
    val remainingInstallments: Int = 1
)
