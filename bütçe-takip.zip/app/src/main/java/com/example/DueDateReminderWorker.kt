package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Son ödeme gününe 1 gün kala veya bugün olan ödenmemiş borçları denetleyip
 * kullanıcıya bildirim gönderen WorkManager Worker'ı.
 */
class DueDateReminderWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        const val CHANNEL_ID = "budget_reminders_channel"
        const val WORK_NAME = "budget_due_date_reminder_work"

        /**
         * Günlük periyodik hatırlatıcı görevini zamanlar.
         */
        fun scheduleDailyReminder(context: Context) {
            val workRequest = PeriodicWorkRequestBuilder<DueDateReminderWorker>(
                1, TimeUnit.DAYS
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
        }
    }

    override suspend fun doWork(): Result {
        val database = AppDatabase.getDatabase(context)
        val expenses = database.expenseDao().getAllExpensesList()

        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val maxDaysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)

        // Yarının günü
        val tomorrowDay = if (currentDay == maxDaysInMonth) 1 else currentDay + 1

        val urgentExpenses = expenses.filter { !it.isPaid && (it.dueDateDay == tomorrowDay || it.dueDateDay == currentDay) }

        if (urgentExpenses.isNotEmpty()) {
            sendNotification(urgentExpenses, currentDay, tomorrowDay)
        }

        return Result.success()
    }

    private fun sendNotification(
        urgentExpenses: List<ExpenseEntity>,
        currentDay: Int,
        tomorrowDay: Int
    ) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ödeme Hatırlatıcıları",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Son ödeme günü yaklaşan borçların bildirimleri"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val title = if (urgentExpenses.size == 1) {
            val exp = urgentExpenses.first()
            if (exp.dueDateDay == currentDay) {
                "Bugün Son Gün: ${exp.title}"
            } else {
                "Yarın Son Gün: ${exp.title}"
            }
        } else {
            "Yaklaşan ${urgentExpenses.size} Borç / Ödemeniz Var!"
        }

        val content = urgentExpenses.joinToString(separator = ", ") {
            "${it.title} (${it.amount.toInt()} ₺)"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(1001, notification)
    }
}
